<?php $__env->startSection('title','Listado de posts'); ?>

<?php $__env->startSection('content'); ?>
 <?php if(!empty($resultados)): ?>
 <h3> 
 	 <?php if(!empty($palabra)): ?>
Resultados con la palabra <?php echo e($palabra); ?>


<?php endif; ?>
		
</h3>
<div class="lista">
	<ul  style="list-style: none">
		<?php $__currentLoopData = $resultados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resultado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<span style="color:#00dd00;">	</span>Categoria <?php echo $resultado->categoria->nombre; ?>

		      <li>
		      	<table style="width:100%;border:1px solid black;">
		      		<tr>
		      			<td style="word-break:break-all;width:80%;" >
		      				<h2>
					      			<u>
					      				<a href="<?php echo e(url ('tema',['id' => $resultado->id])); ?>" > <?php echo $resultado->titulo; ?></a></u>
					      					<!-- almacena cada palabra en una posicion distinta de un array.
					      					recorre ese array y SI la posicion [i] tenga una cadena igual a Palabra, entonces imprime esa con un formato diferente.
					      					 por cada iteracion en el array, imprime el valor.. pero antes verifica si es igual a $palabra -->

			 		      				<p style="font-size: 5px"><?php echo str_limit($resultado->post, 40); ?>

					      				</p>
					      			
					      	</h2>

		      			</td>
		      			<td style="width:20%;">
		      				<a class="btn button btn-danger btn-xs" href="<?php echo e(url('destroy',['id' => $resultado->id])); ?>" style="color:#fff;"><span class="glyphicon glyphicon-trash" value="ELIMINAR"></span>ELIMINAR</a>
		      			</td>
		      		</tr>
		      	</table>
		      			      	
		 
		      </li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		
	</ul>
</div>
<center>
	<div class="container-fluid">
		
	<div class="row">	
		<div class="col-xs-12">	
			<?php if(!empty($palabra)): ?>
					<?php echo $resultados->appends(['search' => $palabra])->links(); ?>

			<?php else: ?>
					<?php echo $resultados->links(); ?>

			<?php endif; ?>
	<!--
		->onEachSide(5) laravel 5.8
		fragment('foo'
		->appends(['sort' => 'votes'])
	-->
		</div>
</div>

</div>


</center>
	<center>

<h2><?php echo e($resultados->total()); ?> registros encontrados</h2>		

        Pagina <?php echo e($resultados->currentPage()); ?> </br>
	 	<?php if(!empty($palabra)): ?>
			<?php echo e($resultados->total()); ?> con la palabra <?php echo e($palabra); ?>

		<?php endif; ?>
	</center>
 <?php else: ?>

  <h2>Aun no hay ningun post</h2>
 <?php endif; ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>