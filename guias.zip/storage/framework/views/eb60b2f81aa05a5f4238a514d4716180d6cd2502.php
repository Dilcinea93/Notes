<?php $__env->startSection('title','Editar post'); ?>

<?php $__env->startSection('content'); ?>

              <form method="post" action="<?php echo e(url('update',['id' => $temas->id])); ?>" role="form">
                <?php echo e(csrf_field()); ?>


							<!-- <input name="_method" type="hidden" value="PATCH"> -->

<!-- No se para que es este campo patch, pero si lo quito me da error de methodNotAllowed. Dice No Message -->

                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <span>Categoria</span>

                  <select name="categoria" id="categoria" class="form-control">
                    <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo $categories-> id; ?>">
                        <?php echo $categories-> nombre; ?>

                      </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                
                <label for="titulo">TITULO: </label>
                <input type="text" name="titulo" class="form-control" value="<?php echo e($temas->titulo); ?>">
                            <textarea class="ckeditor" name="post" id="editor1" rows="10" cols="80">
                            	<?php echo e($temas->post); ?>

                            </textarea>

                            <button class="btn btn-info btn-block" type="submit">Actualizar</button>
                    
 </form>
<?php $__env->stopSection(); ?>

<!-- 
pon boton eliminar -->
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>