<?php

namespace App\Http\Controllers;

use App\categoria; use Illuminate\Http\Request;


class categoryController extends Controller
{
    //
}
