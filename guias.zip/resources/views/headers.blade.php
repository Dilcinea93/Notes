@extends('layout')
@section('title','Registrar')


@section('headers')

<div style="background: red; height: 100px; width:200px; ">
	
</div>
@endsection