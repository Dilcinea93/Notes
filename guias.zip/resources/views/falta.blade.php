@extends('layout')
@section('title','FALTA')

@section('content')
<h4> Mas faciles</h4>
<ul>
<li>Hacer ventana modal para que el usuario agregue sus categorias</li>
		<li>Limpiar el codigo, unificar funciones</li>
	<li>
		-Ajustar el diseño de paginador
	</li>
	<li>	Hacerle un diseño del footer</li>
	<li>Hacer que se vean todos los post en RECENT POSTS</li>
</ul>

<h3>	Mas dificiles</h3>
<ul>


	<li>Hacer que se reinicie el contdor de ID cuando elimine algun post... o que el ID quede de forma secuencial</li>
	<li>Hacer modulo de respaldo de base dd datos.</li>
	<li>Hacer que se pueda guardar la imagen de captura de pantalla</li>
	<li>integrar un editor de codigo como el de stack overflow</li>
</ul>


@endsection



